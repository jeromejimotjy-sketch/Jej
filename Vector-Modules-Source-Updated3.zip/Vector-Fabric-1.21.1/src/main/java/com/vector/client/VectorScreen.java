package com.vector.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Prestige-inspired, lightweight Vector module screen. No background blur is requested. */
public final class VectorScreen extends Screen {
    private static final int BG = 0xF20A0B18;
    private static final int SIDEBAR = 0xF6101222;
    private static final int CARD = 0xF8141729;
    private static final int CARD_HOVER = 0xFF1D2038;
    private static final int LINE = 0xFF292D48;
    private static final int PURPLE = 0xFF8B70FF;
    private static final int TEXT = 0xFFF1F0FF;
    private static final int MUTED = 0xFF8E91AE;

    private final String[] categories = {"Home", "Combat", "Misc", "Movement", "Visual", "Settings", "Theme", "Configs", "Keybinds"};
    private String selectedCategory = "Home";
    private int scrollOffset = 0;
    private String search = "";
    private boolean searching = false;
    private boolean gridView = false;
    private int panelX, panelY, panelW, panelH, sideW;
    private boolean dragging;
    private double grabX, grabY;
    private int offsetX, offsetY;

    private static final class Module {
        final String category, name, description;
        boolean enabled;
        Module(String category, String name, String description, boolean enabled) {
            this.category = category; this.name = name; this.description = description; this.enabled = VectorClient.moduleEnabled(name, enabled);
        }
    }

    private final List<Module> modules = new ArrayList<>(List.of(
        new Module("Visual", "Custom HUD", "Displays the Vector status HUD", true),
        new Module("Visual", "Visual Effects", "Toggle Vector's visual effects", true),
        new Module("Visual", "Name Tags", "Vanilla nametag display preference indicator", false),
        new Module("Visual", "Jump Circles", "Decorative landing ring effects", false),
        new Module("Visual", "Pearl Trajectory", "Shows a projected pearl path", false),
        new Module("Visual", "Full Bright", "Raises client brightness and restores it when disabled", false),
        new Module("Visual", "Tracers", "Visual module placeholder", false),
        new Module("Visual", "Storage ESP", "Visual module placeholder", false),
        new Module("Visual", "Hit Effects", "Decorative hit particles (placeholder)", false),
        new Module("Visual", "Target HUD", "Shows the entity under your crosshair and its health", false),
        new Module("Visual", "No Render", "Render options placeholder", false),
        new Module("Combat", "Combat HUD", "Shows crosshair target type and inventory combat supplies", false),
        new Module("Combat", "Aim Assist", "Not implemented in this build", false),
        new Module("Combat", "Auto Crystal", "Not implemented in this build", false),
        new Module("Combat", "Auto Totem", "Not implemented; use Totem Warning for inventory alerts", false),
        new Module("Combat", "Auto Mace", "Not implemented in this build", false),
        new Module("Movement", "Movement HUD", "Displays movement status", false),
        new Module("Movement", "Sprint", "Shows movement state in the HUD", false),
        new Module("Movement", "Auto Tool", "Selects the strongest suitable hotbar tool for the targeted block", false),
        new Module("Movement", "Fast Place", "Utility placeholder", false),
        new Module("Movement", "Freecam", "Listed for UI organization; not implemented", false),
        new Module("Misc", "Notifications", "Show client notifications", true),
        new Module("Misc", "Optimization", "Status indicator only; does not change game performance", false),
        new Module("Misc", "Socials", "Friend list placeholder", false),
        new Module("Misc", "Configs", "Local configuration placeholder", false),
        new Module("Visual", "Coordinates", "Show live player coordinates in the HUD", false),
        new Module("Visual", "FPS Counter", "Show current frames per second", true),
        new Module("Visual", "Health HUD", "Show current and maximum health", false),
        new Module("Visual", "Food HUD", "Show hunger level", false),
        new Module("Visual", "Experience HUD", "Show player level", false),
        new Module("Visual", "Speed HUD", "Show horizontal movement speed", false),
        new Module("Visual", "Direction HUD", "Show facing direction", false),
        new Module("Visual", "Dimension HUD", "Show current dimension", false),
        new Module("Visual", "Clock HUD", "Show world time", false),
        new Module("Visual", "Day Counter", "Show in-world day number", false),
        new Module("Visual", "Session Timer", "Show time since client started", false),
        new Module("Visual", "Chunk Coordinates", "Show current chunk coordinates", false),
        new Module("Visual", "Light Level", "Show light level at your position", false),
        new Module("Visual", "Armor HUD", "Show total armor points", false),
        new Module("Visual", "Durability HUD", "Show durability of the item in your main hand", false),
        new Module("Misc", "Totem Warning", "Warns in the HUD if you have no totems in inventory", false),
        new Module("Visual", "Biome HUD", "Show current biome identifier", false),
        new Module("Visual", "Status HUD", "Show grounded or airborne status", false),
        new Module("Visual", "Memory HUD", "Show JVM allocated memory", false),
        new Module("Visual", "Weather HUD", "Show whether it is raining", false),
        new Module("Visual", "Food Saturation", "Show hunger saturation", false),
        new Module("Visual", "XP Progress", "Show experience progress percentage", false),
        new Module("Visual", "Velocity HUD", "Show total velocity magnitude", false),
        new Module("Visual", "Jump State", "Show whether a jump is ready", false),
        new Module("Visual", "Sneak Status", "Show sneak state", false),
        new Module("Visual", "Sprint Status", "Show sprint state", false),
        new Module("Visual", "Water Status", "Show whether you are touching water", false),
        new Module("Visual", "Fire Status", "Show whether you are on fire", false),
        new Module("Visual", "Vehicle Status", "Show whether you are riding a vehicle", false),
        new Module("Visual", "Air Time", "Show remaining air supply", false),
        new Module("Visual", "Block Position", "Show exact block position", false),
        new Module("Visual", "Yaw Pitch", "Show view yaw and pitch", false),
        new Module("Visual", "Game Mode HUD", "Show current game mode", false),
        new Module("Visual", "Potion Count", "Show active status-effect count", false),
        new Module("Visual", "Targeted Block", "Show when the crosshair targets a block", false),
        new Module("Visual", "Targeted Entity", "Show when the crosshair targets an entity", false),
        new Module("Visual", "Particle Effects", "Show particle setting status", false),
        new Module("Visual", "Minimal Crosshair", "Show crosshair style status", false),
        new Module("Misc", "Toggle Sprint", "Automatically sprint while moving forward", false),
        new Module("Misc", "Full Bright", "Raise gamma and restore it when disabled", false),
        new Module("Misc", "Notifications", "Show notification status in HUD", true),
        new Module("Misc", "Safe Mode", "A visible reminder to keep optional modules disabled", false),
        new Module("Movement", "Auto Walk Indicator", "Show forward-key state in HUD", false),
        new Module("Movement", "Landing Indicator", "Show when grounded or airborne", false),
        new Module("Movement", "Motion Readout", "Show total movement velocity", false),
        new Module("Misc", "World Info", "Show dimension and biome information", false),
        new Module("Misc", "Resource Info", "Show allocated memory information", false),
        new Module("Misc", "Time Info", "Show session and world time", false),
        new Module("Misc", "Player Info", "Show health, food, and armor values", false),
        new Module("Misc", "Position Info", "Show coordinates and chunk location", false),
        new Module("Misc", "Movement Info", "Show speed and movement state", false),
        new Module("Misc", "Environment Info", "Show weather and light information", false),
        new Module("Misc", "Debug Info", "Show additional read-only player information", false)
    ));

    public VectorScreen() { super(VectorClient.uiText("Vector Client")); }

    @Override public boolean shouldPause() { return false; }

    // Intentionally suppress vanilla's screen background/blur. We draw our own dim overlay.
    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x72040712);
        layout();
        rounded(ctx, panelX, panelY, panelW, panelH, 12, BG);
        rounded(ctx, panelX + 1, panelY + 1, sideW, panelH - 2, 10, SIDEBAR);
        rounded(ctx, panelX + 8, panelY, panelW - 16, 2, 1, VectorClient.accentColor);
        // Visible close button, designed for touch and mouse input.
        int closeX = panelX + panelW - 30;
        int closeY = panelY + 8;
        rounded(ctx, closeX, closeY, 20, 20, 5, mouseX >= closeX && mouseX <= closeX + 20 && mouseY >= closeY && mouseY <= closeY + 20 ? 0xFF58304F : 0xFF29243F);
        ctx.drawText(MinecraftClient.getInstance().textRenderer, Text.literal("X"), closeX + 6, closeY + 6, 0xFFFFDFFF, false);
        ctx.fill(panelX + sideW, panelY + 12, panelX + sideW + 1, panelY + panelH - 12, LINE);

        var tr = MinecraftClient.getInstance().textRenderer;
        ctx.drawText(tr, VectorClient.uiText("◆  VECTOR"), panelX + 13, panelY + 13, PURPLE, false);
        ctx.drawText(tr, VectorClient.uiText("CLIENT  •  1.21.1"), panelX + 14, panelY + 27, MUTED, false);
        ctx.drawText(tr, VectorClient.uiText("NAVIGATION"), panelX + 14, panelY + 49, MUTED, false);

        int itemY = panelY + 62;
        for (String category : categories) {
            if (category.equals("Settings")) {
                ctx.drawText(tr, VectorClient.uiText("GENERAL"), panelX + 14, itemY + 2, MUTED, false);
                itemY += 15;
            }
            boolean active = selectedCategory.equals(category);
            int x1 = panelX + 7, x2 = panelX + sideW - 7;
            if (active) {
                rounded(ctx, x1, itemY - 4, x2 - x1, 20, 6, 0xFF28234A);
                rounded(ctx, x1, itemY - 4, 3, 20, 2, VectorClient.accentColor);
            }
            ctx.drawText(tr, VectorClient.uiText(categoryIcon(category) + "  " + category), panelX + 15, itemY + 2,
                    active ? TEXT : 0xFFB7B8CD, false);
            itemY += 23;
        }

        int contentX = panelX + sideW + 14;
        int contentW = panelW - sideW - 28;
        String title = selectedCategory.equals("Visual") ? "Visual Modules" : selectedCategory;
        ctx.drawText(tr, VectorClient.uiText(title), contentX, panelY + 14, TEXT, false);
        int count = 0;
        for (Module m : modules) if (m.category.equals(selectedCategory)) count++;
        ctx.drawText(tr, VectorClient.uiText(selectedCategory.equals("Visual") ? "Modules and visual options" : "Vector settings and modules"),
                contentX, panelY + 28, MUTED, false);

        int searchY = panelY + 46;
        rounded(ctx, contentX, searchY, contentW, 22, 7, 0xFF101326);
        rounded(ctx, contentX, searchY, contentW, 1, 1, LINE);
        String searchLabel = searching ? "Search: " + search + "_" : (search.isEmpty() ? "⌕  Search modules" : "⌕  " + search);
        ctx.drawText(tr, VectorClient.uiText(searchLabel), contentX + 8, searchY + 7, searching ? TEXT : MUTED, false);
        ctx.drawText(tr, VectorClient.uiText(gridView ? "▦" : "☷"), contentX + contentW - 15, searchY + 7, TEXT, false);

        if (selectedCategory.equals("Home")) {
            int hy = searchY + 38;
            rounded(ctx, contentX, hy, contentW, 74, 9, CARD);
            ctx.drawText(tr, VectorClient.uiText("Welcome to Vector"), contentX + 12, hy + 10, TEXT, false);
            ctx.drawText(tr, VectorClient.uiText("Fabric client for Minecraft 1.21.1"), contentX + 12, hy + 26, MUTED, false);
            ctx.drawText(tr, VectorClient.uiText("Use the sidebar to browse modules, or search above."), contentX + 12, hy + 42, MUTED, false);
            int cy = hy + 90;
            ctx.drawText(tr, VectorClient.uiText("CREDITS"), contentX + 2, cy, VectorClient.accentColor, false);
            ctx.drawText(tr, VectorClient.uiText("Project: Vector"), contentX + 2, cy + 20, TEXT, false);
            ctx.drawText(tr, VectorClient.uiText("UI and code assistance: ChatGPT"), contentX + 2, cy + 36, TEXT, false);
            ctx.drawText(tr, VectorClient.uiText("Built with Fabric API for Minecraft 1.21.1"), contentX + 2, cy + 52, MUTED, false);
            ctx.drawText(tr, VectorClient.uiText("Made for learning, customization, and testing."), contentX + 2, cy + 68, MUTED, false);
        }
        if (selectedCategory.equals("Theme")) {
            ctx.drawText(tr, VectorClient.uiText("ACCENT COLOR  •  TAP THE BAR TO PICK"), contentX, searchY + 34, MUTED, false);
            int barY = searchY + 54; int barW = contentW;
            for (int i = 0; i < barW; i++) { int rgb = java.awt.Color.HSBtoRGB((float)i / Math.max(1, barW), 0.62f, 1.0f); ctx.fill(contentX + i, barY, contentX + i + 1, barY + 18, 0xFF000000 | (rgb & 0xFFFFFF)); }
            rounded(ctx, contentX, barY + 24, contentW, 24, 7, CARD);
            ctx.drawText(tr, VectorClient.uiText("Accent preview  •  saved automatically"), contentX + 9, barY + 32, VectorClient.accentColor, false);
        }
        int y = searchY + 30 - scrollOffset;
        int cardH = gridView ? 56 : 39;
        int gap = 6;
        int visible = 0;
        for (Module m : modules) {
            if (selectedCategory.equals("Home")) break;
            if (!m.category.equals(selectedCategory)) continue;
            if (!search.isEmpty() && !(m.name + " " + m.description).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            int x = contentX;
            int w = contentW;
            if (y + cardH < searchY + 24) { y += cardH + gap; continue; }
            if (y > panelY + panelH - 10) break;
            boolean hover = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + cardH;
            rounded(ctx, x, y, w, cardH, 7, hover ? CARD_HOVER : CARD);
            rounded(ctx, x + 6, y, w - 12, 1, 1, LINE);
            ctx.drawText(tr, VectorClient.uiText(m.name), x + 10, y + 7, TEXT, false);
            ctx.drawText(tr, VectorClient.uiText(m.description), x + 10, y + 20, MUTED, false);
            int sx = x + w - 28, sy = y + (cardH - 12) / 2;
            ctx.fill(sx, sy, sx + 20, sy + 12, m.enabled ? VectorClient.accentColor : 0xFF292C40);
            rounded(ctx, m.enabled ? sx + 10 : sx + 2, sy + 2, 8, 8, 4,
                    m.enabled ? 0xFFEDE9FF : 0xFF8588A0);
            visible++;
            y += cardH + gap;
        }
        if (visible == 0) ctx.drawText(tr, VectorClient.uiText("No modules found"), contentX + 8, y + 8, MUTED, false);
        ctx.drawText(tr, VectorClient.uiText("Tap X to close  •  Right Shift toggles menu"), panelX + sideW + 14,
                panelY + panelH - 13, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private static void rounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w / 2, h / 2)));
        if (r == 0) { ctx.fill(x, y, x + w, y + h, color); return; }
        for (int row = 0; row < h; row++) {
            int inset = 0;
            if (row < r) { double dy = r - row - 0.5; inset = Math.max(0, r - (int)Math.sqrt(Math.max(0, r * r - dy * dy))); }
            else if (row >= h - r) { double dy = row - (h - r) + 0.5; inset = Math.max(0, r - (int)Math.sqrt(Math.max(0, r * r - dy * dy))); }
            ctx.fill(x + inset, y + row, x + w - inset, y + row + 1, color);
        }
    }

    private void layout() {
        panelW = Math.min(620, Math.max(300, width - 20));
        panelH = Math.min(390, Math.max(190, height - 20));
        sideW = Math.min(142, Math.max(100, panelW / 3));
        panelX = Math.max(0, Math.min(width - panelW, (width - panelW) / 2 + offsetX));
        panelY = Math.max(0, Math.min(height - panelH, (height - panelH) / 2 + offsetY));
    }

    private String categoryIcon(String category) {
        return switch (category) {
            case "Home" -> "⌂"; case "Combat" -> "⚔"; case "Misc" -> "◆"; case "Movement" -> "↗";
            case "Visual" -> "◉"; case "Settings" -> "☰"; case "Theme" -> "◐";
            case "Configs" -> "▱"; case "Keybinds" -> "⌨"; default -> "•";
        };
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button != 0) return super.mouseClicked(x, y, button);
        layout();
        int closeX = panelX + panelW - 30;
        int closeY = panelY + 8;
        if (x >= closeX && x <= closeX + 20 && y >= closeY && y <= closeY + 20) {
            close();
            return true;
        }
        int contentX = panelX + sideW + 14;
        int contentW = panelW - sideW - 28;
        int itemY = panelY + 62;
        for (String category : categories) {
            if (category.equals("Settings")) itemY += 15;
            if (x >= panelX + 7 && x <= panelX + sideW - 7 && y >= itemY - 4 && y <= itemY + 16) {
                selectedCategory = category; searching = false; search = ""; scrollOffset = 0; return true;
            }
            itemY += 23;
        }
        int searchY = panelY + 46;
        if (selectedCategory.equals("Theme")) {
            if (y >= searchY && y <= searchY + 110 && x >= contentX && x <= contentX + contentW) {
                float hue = ((float)(x - contentX) / Math.max(1, contentW));
                int rgb = java.awt.Color.HSBtoRGB(hue, 0.62f, 1.0f);
                VectorClient.accentColor = 0xFF000000 | (rgb & 0x00FFFFFF); VectorClient.saveConfig(); return true;
            }
        }
        if (x >= contentX && x <= contentX + contentW && y >= searchY && y <= searchY + 22) {
            if (x > contentX + contentW - 24) gridView = !gridView;
            else searching = true;
            return true;
        }
        if (selectedCategory.equals("Home")) return true;
        int cardY = searchY + 30 - scrollOffset;
        int cardH = gridView ? 56 : 39;
        for (Module m : modules) {
            if (!m.category.equals(selectedCategory)) continue;
            if (!search.isEmpty() && !(m.name + " " + m.description).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            if (x >= contentX && x <= contentX + contentW && y >= cardY && y <= cardY + cardH) {
                m.enabled = !m.enabled;
                VectorClient.setModuleEnabled(m.name, m.enabled);
                return true;
            }
            cardY += cardH + 6;
        }
        if (x >= panelX && x <= panelX + sideW && y >= panelY && y <= panelY + 42) {
            dragging = true; grabX = x - panelX; grabY = y - panelY;
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        layout();
        int contentX = panelX + sideW + 14;
        int contentW = panelW - sideW - 28;
        if (mouseX >= contentX && mouseX <= contentX + contentW && !selectedCategory.equals("Home") && !selectedCategory.equals("Theme")) {
            int total = 0;
            for (Module m : modules) if (m.category.equals(selectedCategory) && (search.isEmpty() || (m.name + " " + m.description).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT)))) total++;
            int cardH = gridView ? 56 : 39;
            int max = Math.max(0, total * (cardH + 6) - (panelH - 100));
            scrollOffset = Math.max(0, Math.min(max, scrollOffset - (int)(verticalAmount * 24)));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override public boolean charTyped(char chr, int modifiers) {
        if (searching && !Character.isISOControl(chr)) { search += chr; return true; }
        return super.charTyped(chr, modifiers);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searching) {
            if (keyCode == 256) { searching = false; return true; }
            if (keyCode == 259 && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean mouseDragged(double x, double y, int button, double deltaX, double deltaY) {
        if (!dragging) return super.mouseDragged(x, y, button, deltaX, deltaY);
        int baseX = (width - panelW) / 2;
        int baseY = (height - panelH) / 2;
        offsetX = (int) (x - grabX) - baseX;
        offsetY = (int) (y - grabY) - baseY;
        layout();
        return true;
    }
    @Override public boolean mouseReleased(double x, double y, int button) { dragging = false; return super.mouseReleased(x, y, button); }
    @Override public void close() { VectorClient.saveConfig(); MinecraftClient.getInstance().setScreen(null); }
}
