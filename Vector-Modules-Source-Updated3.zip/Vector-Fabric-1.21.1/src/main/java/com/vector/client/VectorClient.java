package com.vector.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import org.lwjgl.glfw.GLFW;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

public final class VectorClient implements ClientModInitializer {
    public static boolean hudEnabled = true;
    public static boolean visualEffectsEnabled = true;
    public static int accentColor = 0xFF9B78FF;
    private static final Path CONFIG = FabricLoader.getInstance().getConfigDir().resolve("vector.properties");
    private static final Map<String, Boolean> MODULES = new LinkedHashMap<>();
    private static KeyBinding openMenu;
    private static long startedAt = System.currentTimeMillis();
    private static double savedGamma = 1.0;
    private static boolean gammaCaptured = false;
    private static boolean sprintWasForced = false;

    public static boolean moduleEnabled(String name, boolean defaultValue) {
        return MODULES.getOrDefault(name, defaultValue);
    }
    public static void setModuleEnabled(String name, boolean enabled) {
        MODULES.put(name, enabled);
        if (name.equals("Custom HUD")) hudEnabled = enabled;
        if (name.equals("Visual Effects")) visualEffectsEnabled = enabled;
        saveConfig();
    }
    public static boolean toggleModule(String name, boolean defaultValue) {
        boolean next = !moduleEnabled(name, defaultValue);
        setModuleEnabled(name, next);
        return next;
    }
    private static void loadConfig() {
        try {
            if (!Files.exists(CONFIG)) return;
            Properties p = new Properties();
            try (var in = Files.newInputStream(CONFIG)) { p.load(in); }
            accentColor = (int) Long.parseLong(p.getProperty("accent", "ff9b78ff"), 16);
            hudEnabled = Boolean.parseBoolean(p.getProperty("hud", "true"));
            visualEffectsEnabled = Boolean.parseBoolean(p.getProperty("effects", "true"));
            for (String key : p.stringPropertyNames()) {
                if (key.startsWith("module.")) MODULES.put(key.substring(7), Boolean.parseBoolean(p.getProperty(key)));
            }
        } catch (Exception ignored) { }
    }
    public static void saveConfig() {
        try {
            Properties p = new Properties();
            p.setProperty("accent", String.format("%08x", accentColor));
            p.setProperty("hud", Boolean.toString(hudEnabled));
            p.setProperty("effects", Boolean.toString(visualEffectsEnabled));
            MODULES.forEach((name, enabled) -> p.setProperty("module." + name, Boolean.toString(enabled)));
            Files.createDirectories(CONFIG.getParent());
            try (var out = Files.newOutputStream(CONFIG)) { p.store(out, "Vector client settings"); }
        } catch (Exception ignored) { }
    }
    public static Text uiText(String value) {
        return Text.literal(value);
    }

    @Override public void onInitializeClient() {
        loadConfig();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vector.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.vector.main"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen instanceof VectorScreen) client.setScreen(null);
                else if (client.currentScreen == null) client.setScreen(new VectorScreen());
            }
            // Toggle Sprint only requests sprint while moving forward and restores the key state
            // when disabled so it never leaves the vanilla key artificially pressed.
            if (client.player != null && client.options != null && moduleEnabled("Toggle Sprint", false)) {
                boolean movingForward = client.options.forwardKey.isPressed();
                boolean sneaking = client.player.isSneaking();
                client.options.sprintKey.setPressed(movingForward && !sneaking && client.player.getHungerManager().getFoodLevel() > 6);
                sprintWasForced = true;
            } else if (client.options != null && sprintWasForced) {
                client.options.sprintKey.setPressed(false);
                sprintWasForced = false;
            }
            // Auto Tool chooses the strongest suitable item in the hotbar for the block
            // currently under the crosshair. It never clicks or attacks for the player.
            if (client.player != null && client.world != null && client.options != null
                    && moduleEnabled("Auto Tool", false)
                    && client.crosshairTarget instanceof BlockHitResult hit
                    && hit.getType() == HitResult.Type.BLOCK) {
                var state = client.world.getBlockState(hit.getBlockPos());
                int bestSlot = client.player.getInventory().selectedSlot;
                float bestSpeed = client.player.getInventory().getStack(bestSlot).getMiningSpeedMultiplier(state);
                for (int slot = 0; slot < 9; slot++) {
                    var stack = client.player.getInventory().getStack(slot);
                    float speed = stack.getMiningSpeedMultiplier(state);
                    if (stack.isSuitableFor(state) && speed > bestSpeed) {
                        bestSpeed = speed;
                        bestSlot = slot;
                    }
                }
                if (bestSlot != client.player.getInventory().selectedSlot) client.player.getInventory().selectedSlot = bestSlot;
            }
            // Full Bright is a real client option, and restores the previous gamma when disabled.
            if (client.options != null && moduleEnabled("Full Bright", false)) {
                if (!gammaCaptured) { savedGamma = client.options.getGamma().getValue(); gammaCaptured = true; }
                client.options.getGamma().setValue(16.0);
            } else if (client.options != null && gammaCaptured) {
                client.options.getGamma().setValue(savedGamma); gammaCaptured = false;
            }
        });
        HudRenderCallback.EVENT.register((context, tickCounter) -> renderHud(context));
    }

    private static void renderHud(net.minecraft.client.gui.DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.textRenderer == null || client.player == null || client.world == null) return;
        renderVisualOverlays(context, client);
        if (!hudEnabled) return;
        int x = 8, y = 8, line = 12;
        context.fill(x - 3, y - 3, x + 150, y + 22, 0xA60B0D10);
        context.fill(x - 3, y - 3, x, y + 22, accentColor);
        context.drawText(client.textRenderer, uiText("VECTOR"), x + 3, y, 0xFFE8F3F0, false);
        context.drawText(client.textRenderer, uiText("1.21.1  •  " + client.getCurrentFps() + " FPS"), x + 3, y + line, 0xFFB9C7C3, false);
        int yy = y + 29;
        yy = hudLine(context, client, "Coordinates", "XYZ  " + client.player.getBlockX() + "  " + client.player.getBlockY() + "  " + client.player.getBlockZ(), x, yy, line);
        yy = hudLine(context, client, "FPS Counter", "FPS  " + client.getCurrentFps(), x, yy, line);
        yy = hudLine(context, client, "Health HUD", String.format(java.util.Locale.ROOT, "Health  %.1f / %.1f", client.player.getHealth(), client.player.getMaxHealth()), x, yy, line);
        yy = hudLine(context, client, "Food HUD", "Food  " + client.player.getHungerManager().getFoodLevel() + "/20", x, yy, line);
        yy = hudLine(context, client, "Experience HUD", "Level  " + client.player.experienceLevel, x, yy, line);
        yy = hudLine(context, client, "Speed HUD", String.format(java.util.Locale.ROOT, "Speed  %.2f m/s", client.player.getVelocity().horizontalLength() * 20.0), x, yy, line);
        yy = hudLine(context, client, "Direction HUD", "Facing  " + client.player.getHorizontalFacing().asString().toUpperCase(java.util.Locale.ROOT), x, yy, line);
        yy = hudLine(context, client, "Dimension HUD", "World  " + client.world.getRegistryKey().getValue().getPath(), x, yy, line);
        yy = hudLine(context, client, "Clock HUD", "Time  " + (client.world.getTimeOfDay() % 24000L), x, yy, line);
        yy = hudLine(context, client, "Day Counter", "Day  " + (client.world.getTimeOfDay() / 24000L), x, yy, line);
        yy = hudLine(context, client, "Session Timer", "Session  " + ((System.currentTimeMillis() - startedAt) / 60000) + " min", x, yy, line);
        yy = hudLine(context, client, "Chunk Coordinates", "Chunk  " + (client.player.getBlockX() >> 4) + ", " + (client.player.getBlockZ() >> 4), x, yy, line);
        yy = hudLine(context, client, "Light Level", "Light  " + client.world.getLightLevel(client.player.getBlockPos()), x, yy, line);
        yy = hudLine(context, client, "Armor HUD", "Armor  " + client.player.getArmor(), x, yy, line);
        yy = hudLine(context, client, "Biome HUD", "Biome  " + client.world.getBiome(client.player.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("unknown"), x, yy, line);
        yy = hudLine(context, client, "Status HUD", client.player.isOnGround() ? "Status  Grounded" : "Status  Airborne", x, yy, line);
        yy = hudLine(context, client, "Memory HUD", "Memory  " + (Runtime.getRuntime().totalMemory() / 1048576) + " MB", x, yy, line);
        yy = hudLine(context, client, "Weather HUD", client.world.isRaining() ? "Weather  Rain" : "Weather  Clear", x, yy, line);
        yy = hudLine(context, client, "Food Saturation", String.format(java.util.Locale.ROOT, "Saturation  %.1f", client.player.getHungerManager().getSaturationLevel()), x, yy, line);
        yy = hudLine(context, client, "XP Progress", String.format(java.util.Locale.ROOT, "XP  %.0f%%", client.player.experienceProgress * 100), x, yy, line);
        yy = hudLine(context, client, "Velocity HUD", String.format(java.util.Locale.ROOT, "Velocity  %.2f", client.player.getVelocity().length()), x, yy, line);
        yy = hudLine(context, client, "Jump State", client.player.isOnGround() ? "Jump  Ready" : "Jump  In air", x, yy, line);
        yy = hudLine(context, client, "Sneak Status", client.player.isSneaking() ? "Sneak  On" : "Sneak  Off", x, yy, line);
        yy = hudLine(context, client, "Sprint Status", client.player.isSprinting() ? "Sprint  On" : "Sprint  Off", x, yy, line);
        yy = hudLine(context, client, "Water Status", client.player.isTouchingWater() ? "Water  Yes" : "Water  No", x, yy, line);
        yy = hudLine(context, client, "Fire Status", client.player.isOnFire() ? "Fire  Yes" : "Fire  No", x, yy, line);
        yy = hudLine(context, client, "Vehicle Status", client.player.hasVehicle() ? "Vehicle  Mounted" : "Vehicle  None", x, yy, line);
        yy = hudLine(context, client, "Air Time", "Air  " + client.player.getAir() + "/300", x, yy, line);
        yy = hudLine(context, client, "Block Position", "Block  " + client.player.getBlockPos().toShortString(), x, yy, line);
        yy = hudLine(context, client, "Yaw Pitch", String.format(java.util.Locale.ROOT, "Yaw/Pitch  %.0f / %.0f", client.player.getYaw(), client.player.getPitch()), x, yy, line);
        yy = hudLine(context, client, "Game Mode HUD", client.interactionManager == null ? "Mode  ?" : "Mode  " + client.interactionManager.getCurrentGameMode().getName(), x, yy, line);
        yy = hudLine(context, client, "Potion Count", "Effects  " + client.player.getStatusEffects().size(), x, yy, line);
        yy = hudLine(context, client, "Targeted Block", client.crosshairTarget != null && client.crosshairTarget.getType().toString().equals("BLOCK") ? "Block target  Yes" : "Block target  No", x, yy, line);
        yy = hudLine(context, client, "Targeted Entity", client.crosshairTarget != null && client.crosshairTarget.getType().toString().equals("ENTITY") ? "Entity target  Yes" : "Entity target  No", x, yy, line);
        yy = hudLine(context, client, "Particle Status", moduleEnabled("Particle Effects", false) ? "Particles  Enabled" : "Particles  Default", x, yy, line);
        yy = hudLine(context, client, "Minimal Crosshair", moduleEnabled("Minimal Crosshair", false) ? "Crosshair  Minimal" : "Crosshair  Default", x, yy, line);
        yy = hudLine(context, client, "Notifications", moduleEnabled("Notifications", true) ? "Notifications  On" : "Notifications  Off", x, yy, line);
        yy = hudLine(context, client, "Safe Mode", "Safe Mode  " + (moduleEnabled("Safe Mode", false) ? "On" : "Off"), x, yy, line);
        yy = hudLine(context, client, "Auto Walk Indicator", "Forward key  " + (client.options.forwardKey.isPressed() ? "Pressed" : "Released"), x, yy, line);
        yy = hudLine(context, client, "Landing Indicator", client.player.isOnGround() ? "Landing  Grounded" : "Landing  Airborne", x, yy, line);
        yy = hudLine(context, client, "Motion Readout", String.format(java.util.Locale.ROOT, "Motion  %.2f", client.player.getVelocity().length()), x, yy, line);
        yy = hudLine(context, client, "World Info", "World  " + client.world.getRegistryKey().getValue().getPath(), x, yy, line);
        yy = hudLine(context, client, "Resource Info", "Allocated  " + (Runtime.getRuntime().totalMemory() / 1048576) + " MB", x, yy, line);
        yy = hudLine(context, client, "Time Info", "World time  " + (client.world.getTimeOfDay() % 24000L), x, yy, line);
        yy = hudLine(context, client, "Player Info", String.format(java.util.Locale.ROOT, "HP %.1f  Food %d  Armor %d", client.player.getHealth(), client.player.getHungerManager().getFoodLevel(), client.player.getArmor()), x, yy, line);
        yy = hudLine(context, client, "Position Info", "Pos  " + client.player.getBlockPos().toShortString(), x, yy, line);
        yy = hudLine(context, client, "Movement Info", String.format(java.util.Locale.ROOT, "Move  %.2f m/s", client.player.getVelocity().horizontalLength() * 20.0), x, yy, line);
        yy = hudLine(context, client, "Environment Info", (client.world.isRaining() ? "Rain" : "Clear") + "  •  Light " + client.world.getLightLevel(client.player.getBlockPos()), x, yy, line);
        hudLine(context, client, "Debug Info", String.format(java.util.Locale.ROOT, "Yaw %.0f  Pitch %.0f", client.player.getYaw(), client.player.getPitch()), x, yy, line);
    }
    /** Lightweight screen-space visual aids. These are client-side indicators, not through-wall world geometry. */
    private static void renderVisualOverlays(net.minecraft.client.gui.DrawContext context, MinecraftClient client) {
        int sw = client.getWindow().getScaledWidth();
        int sh = client.getWindow().getScaledHeight();
        int right = sw - 8;
        int y = 10;
        if (moduleEnabled("Name Tags", false) || moduleEnabled("Tracers", false)) {
            var entities = client.world.getEntitiesByClass(net.minecraft.entity.LivingEntity.class,
                    client.player.getBoundingBox().expand(32), e -> e != client.player && e.isAlive());
            int shown = 0;
            for (var entity : entities) {
                if (shown >= 8) break;
                double dx = entity.getX() - client.player.getX();
                double dz = entity.getZ() - client.player.getZ();
                double distance = Math.sqrt(dx * dx + dz * dz);
                double bearing = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
                double difference = wrapDegrees(bearing - client.player.getYaw());
                int markerX = Math.max(6, Math.min(sw - 6, sw / 2 + (int)(difference * 2.0)));
                if (moduleEnabled("Tracers", false)) {
                    // Compact directional tracer marker at the screen edge/target bearing.
                    drawLine(context, sw / 2, sh - 24, markerX, Math.max(20, sh / 2), accentColor);
                }
                if (moduleEnabled("Name Tags", false)) {
                    String label = entity.getDisplayName().getString() + "  " + (int)distance + "m";
                    int labelW = client.textRenderer.getWidth(label) + 8;
                    int lx = Math.max(4, Math.min(sw - labelW - 4, markerX - labelW / 2));
                    context.fill(lx, y, lx + labelW, y + 12, 0xB20B0D18);
                    context.drawText(client.textRenderer, Text.literal(label), lx + 4, y + 2, 0xFFFFFFFF, false);
                    y += 14;
                }
                shown++;
            }
        }
        if (moduleEnabled("Storage ESP", false)) {
            int shown = 0;
            var pos = client.player.getBlockPos();
            for (int dy = 3; dy >= -3 && shown < 8; dy--) {
                for (int dx = -6; dx <= 6 && shown < 8; dx++) {
                    for (int dz = -6; dz <= 6 && shown < 8; dz++) {
                        var blockPos = pos.add(dx, dy, dz);
                        var id = net.minecraft.registry.Registries.BLOCK.getId(client.world.getBlockState(blockPos).getBlock()).getPath();
                        if (id.equals("chest") || id.equals("trapped_chest") || id.equals("barrel") || id.endsWith("shulker_box")) {
                            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
                            String label = id.replace('_', ' ') + " " + (int)dist + "m (" + blockPos.getX() + "," + blockPos.getY() + "," + blockPos.getZ() + ")";
                            int labelW = Math.min(sw - 12, client.textRenderer.getWidth(label) + 8);
                            context.fill(right - labelW, y, right, y + 12, 0xB20B0D18);
                            context.drawText(client.textRenderer, Text.literal(label), right - labelW + 4, y + 2, 0xFFFFD780, false);
                            y += 14;
                            shown++;
                        }
                    }
                }
            }
        }
    }

    private static float wrapDegrees(double value) {
        value %= 360.0;
        if (value >= 180.0) value -= 360.0;
        if (value < -180.0) value += 360.0;
        return (float)value;
    }

    private static void drawLine(net.minecraft.client.gui.DrawContext context, int x0, int y0, int x1, int y1, int color) {
        int dx = Math.abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
        int dy = -Math.abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
        int err = dx + dy;
        while (true) {
            context.fill(x0, y0, x0 + 2, y0 + 2, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    private static int countItem(MinecraftClient client, String itemPath) {
        int count = 0;
        var inventory = client.player.getInventory();
        for (int i = 0; i < 36; i++) {
            var stack = inventory.getStack(i);
            if (net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath().equals(itemPath)) count += stack.getCount();
        }
        var offhand = client.player.getOffHandStack();
        if (net.minecraft.registry.Registries.ITEM.getId(offhand.getItem()).getPath().equals(itemPath)) count += offhand.getCount();
        return count;
    }

    private static String durability(net.minecraft.item.ItemStack stack) {
        if (!stack.isDamageable()) return "N/A";
        return (stack.getMaxDamage() - stack.getDamage()) + "/" + stack.getMaxDamage();
    }

    private static int hudLine(net.minecraft.client.gui.DrawContext context, MinecraftClient client, String module, String value, int x, int y, int line) {
        if (!moduleEnabled(module, false) || y > client.getWindow().getScaledHeight() - 12) return y;
        context.fill(x - 3, y - 2, x + 152, y + 10, 0x880B0D10);
        context.fill(x - 3, y - 2, x - 1, y + 10, accentColor);
        context.drawText(client.textRenderer, uiText(value), x + 3, y, 0xFFE8F3F0, false);
        return y + line;
    }
}
