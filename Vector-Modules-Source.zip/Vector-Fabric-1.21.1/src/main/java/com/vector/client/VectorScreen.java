package com.vector.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Prestige-inspired, lightweight Vector module screen. No background blur is requested. */
public final class VectorScreen extends Screen {
    private static final int BG = 0xF20A0B18;
    private static final int SIDEBAR = 0xF6101222;
    private static final int CARD = 0xF8141729;
    private static final int CARD_HOVER = 0xFF1D2038;
    private static final int LINE = 0xFF292D48;
    private static final int PURPLE = 0xFF8B70FF;
    private static final int TEXT = 0xFFF1F0FF;
    private static final int MUTED = 0xFF8E91AE;

    private final String[] categories = {"Combat", "Misc", "Movement", "Visual", "Settings", "Theme", "Configs", "Keybinds"};
    private String selectedCategory = "Visual";
    private String search = "";
    private boolean searching = false;
    private boolean gridView = false;
    private int panelX, panelY, panelW, panelH, sideW;
    private boolean dragging;
    private double grabX, grabY;
    private int offsetX, offsetY;

    private static final class Module {
        final String category, name, description;
        boolean enabled;
        Module(String category, String name, String description, boolean enabled) {
            this.category = category; this.name = name; this.description = description; this.enabled = enabled;
        }
    }

    private final List<Module> modules = new ArrayList<>(List.of(
        new Module("Visual", "Custom HUD", "Displays the Vector status HUD", true),
        new Module("Visual", "Visual Effects", "Toggle Vector's visual effects", true),
        new Module("Visual", "Name Tags", "Module placeholder — no player tracking", false),
        new Module("Visual", "Jump Circles", "Decorative landing ring effects", false),
        new Module("Visual", "Pearl Trajectory", "Shows a projected pearl path", false),
        new Module("Visual", "Full Bright", "Client-side brightness setting (UI toggle)", false),
        new Module("Visual", "Tracers", "Visual module placeholder", false),
        new Module("Visual", "Storage ESP", "Visual module placeholder", false),
        new Module("Visual", "Hit Effects", "Decorative hit particles (placeholder)", false),
        new Module("Visual", "Target HUD", "Displays target information (placeholder)", false),
        new Module("Visual", "No Render", "Render options placeholder", false),
        new Module("Combat", "Combat HUD", "Displays combat-related status", false),
        new Module("Combat", "Aim Assist", "Listed for UI organization; not implemented", false),
        new Module("Combat", "Auto Crystal", "Listed for UI organization; not implemented", false),
        new Module("Combat", "Auto Totem", "Listed for UI organization; not implemented", false),
        new Module("Combat", "Auto Mace", "Listed for UI organization; not implemented", false),
        new Module("Movement", "Movement HUD", "Displays movement status", false),
        new Module("Movement", "Sprint", "Movement utility placeholder", false),
        new Module("Movement", "Auto Tool", "Utility placeholder", false),
        new Module("Movement", "Fast Place", "Utility placeholder", false),
        new Module("Movement", "Freecam", "Listed for UI organization; not implemented", false),
        new Module("Misc", "Notifications", "Show client notifications", true),
        new Module("Misc", "Optimization", "Performance options placeholder", false),
        new Module("Misc", "Socials", "Friend list placeholder", false),
        new Module("Misc", "Configs", "Local configuration placeholder", false),
        // Visual tools
        new Module("Visual", "ESP (Test Overlay)", "Local test overlay indicator; no entity highlighting yet", false),
        new Module("Visual", "Tracers", "Visual test toggle; no lines rendered yet", false),
        new Module("Visual", "Storage ESP", "Storage-test toggle; rendering not implemented", false),
        new Module("Visual", "Full Bright", "Brightness test toggle", false),
        new Module("Visual", "Hit Effects", "Decorative hit-effect test toggle", false),
        new Module("Visual", "Target Renderer", "Target display test toggle", false),
        new Module("Visual", "No Render", "Render test toggle", false),
        new Module("Visual", "Item Physics", "Item-render test toggle", false),
        new Module("Visual", "Crosshair", "Custom crosshair test toggle", false),
        new Module("Visual", "Armor HUD", "Armor display test toggle", false),
        new Module("Visual", "Keystrokes", "Keystroke HUD test toggle", false),
        new Module("Visual", "Coordinates", "Coordinate HUD test toggle", false),
        // Combat / anti-cheat lab entries are UI-only toggles; they do not automate attacks.
        new Module("Combat", "Aim Trainer", "Practice indicator only; no automated aiming", false),
        new Module("Combat", "Kill Aura (Lab Toggle)", "UI test only; no automatic attacks", false),
        new Module("Combat", "Silent Aim (Lab Toggle)", "UI test only; no aim manipulation", false),
        new Module("Combat", "Trigger Bot (Lab Toggle)", "UI test only; no automatic attacks", false),
        new Module("Combat", "Hitbox Visualizer", "Hitbox-test indicator; no hitbox changes", false),
        new Module("Combat", "W-Tap Trainer", "Timing-practice indicator only", false),
        new Module("Combat", "Crystal PvP Lab", "Test panel toggle; no combat automation", false),
        new Module("Combat", "Anchor PvP Lab", "Test panel toggle; no combat automation", false),
        new Module("Combat", "Mace PvP Lab", "Test panel toggle; no combat automation", false),
        new Module("Combat", "Projectile Trainer", "Practice indicator only", false),
        new Module("Combat", "Attack Timing", "Timing-test indicator only", false),
        // Movement and utility
        new Module("Movement", "Auto Sprint", "Sprint utility test toggle; not wired yet", false),
        new Module("Movement", "Velocity Lab", "Knockback-test indicator only; no packet manipulation", false),
        new Module("Movement", "Jump Timing", "Movement-practice indicator only", false),
        new Module("Movement", "Auto Tool", "Tool-selection test toggle; not wired yet", false),
        new Module("Movement", "Fast Place", "Placement-test toggle; not wired yet", false),
        new Module("Movement", "Auto Armor", "Equipment-test toggle; not wired yet", false),
        new Module("Movement", "Freecam Lab", "Camera-test indicator only; camera not detached", false),
        new Module("Movement", "Bridge Trainer", "Practice indicator only; no auto-placement", false),
        new Module("Movement", "Fake Lag Lab", "Network-test indicator only; no packet delaying", false),
        // Misc / developer test tools
        new Module("Misc", "Anti Bot Lab", "Detection-test indicator only", false),
        new Module("Misc", "Anti Action Lab", "Detection-test indicator only", false),
        new Module("Misc", "Performance Monitor", "Performance-test indicator only", false),
        new Module("Misc", "Packet Telemetry", "Telemetry panel toggle; no packets altered", false),
        new Module("Misc", "Anti-Cheat Test Mode", "Local test-mode indicator", false),
        new Module("Misc", "Friend List", "Social list UI toggle", false),
        new Module("Misc", "Self Destruct", "Safety test toggle only; does not delete files", false),
        new Module("Misc", "Notifications", "Show client notifications", true)
    ));

    public VectorScreen() { super(Text.literal("Vector Client")); }

    @Override public boolean shouldPause() { return false; }

    // Intentionally suppress vanilla's screen background/blur. We draw our own dim overlay.
    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x72040712);
        layout();
        rounded(ctx, panelX, panelY, panelW, panelH, 12, BG);
        rounded(ctx, panelX + 1, panelY + 1, sideW, panelH - 2, 10, SIDEBAR);
        rounded(ctx, panelX + 8, panelY, panelW - 16, 2, 1, VectorClient.accentColor);
        ctx.fill(panelX + sideW, panelY + 12, panelX + sideW + 1, panelY + panelH - 12, LINE);

        var tr = MinecraftClient.getInstance().textRenderer;
        ctx.drawText(tr, Text.literal("◆  VECTOR"), panelX + 13, panelY + 13, PURPLE, false);
        ctx.drawText(tr, Text.literal("CLIENT  •  1.21.1"), panelX + 14, panelY + 27, MUTED, false);
        ctx.drawText(tr, Text.literal("MODULES"), panelX + 14, panelY + 49, MUTED, false);

        int itemY = panelY + 62;
        for (String category : categories) {
            if (category.equals("Settings")) {
                ctx.drawText(tr, Text.literal("GENERAL"), panelX + 14, itemY + 2, MUTED, false);
                itemY += 15;
            }
            boolean active = selectedCategory.equals(category);
            int x1 = panelX + 7, x2 = panelX + sideW - 7;
            if (active) {
                rounded(ctx, x1, itemY - 4, x2 - x1, 20, 6, 0xFF28234A);
                rounded(ctx, x1, itemY - 4, 3, 20, 2, VectorClient.accentColor);
            }
            ctx.drawText(tr, Text.literal(categoryIcon(category) + "  " + category), panelX + 15, itemY + 2,
                    active ? TEXT : 0xFFB7B8CD, false);
            itemY += 23;
        }

        int contentX = panelX + sideW + 14;
        int contentW = panelW - sideW - 28;
        String title = selectedCategory.equals("Visual") ? "Visual Modules" : selectedCategory;
        ctx.drawText(tr, Text.literal(title), contentX, panelY + 14, TEXT, false);
        int count = 0;
        for (Module m : modules) if (m.category.equals(selectedCategory)) count++;
        ctx.drawText(tr, Text.literal(selectedCategory.equals("Visual") ? "Modules and visual options" : "Vector settings and modules"),
                contentX, panelY + 28, MUTED, false);

        int searchY = panelY + 46;
        rounded(ctx, contentX, searchY, contentW, 22, 7, 0xFF101326);
        rounded(ctx, contentX, searchY, contentW, 1, 1, LINE);
        String searchLabel = searching ? "Search: " + search + "_" : (search.isEmpty() ? "⌕  Search modules" : "⌕  " + search);
        ctx.drawText(tr, Text.literal(searchLabel), contentX + 8, searchY + 7, searching ? TEXT : MUTED, false);
        ctx.drawText(tr, Text.literal(gridView ? "▦" : "☷"), contentX + contentW - 15, searchY + 7, TEXT, false);

        if (selectedCategory.equals("Theme")) {
            ctx.drawText(tr, Text.literal("ACCENT COLOR  •  TAP THE BAR TO PICK"), contentX, searchY + 34, MUTED, false);
            int barY = searchY + 54; int barW = contentW;
            for (int i = 0; i < barW; i++) { int rgb = java.awt.Color.HSBtoRGB((float)i / Math.max(1, barW), 0.62f, 1.0f); ctx.fill(contentX + i, barY, contentX + i + 1, barY + 18, 0xFF000000 | (rgb & 0xFFFFFF)); }
            rounded(ctx, contentX, barY + 24, contentW, 24, 7, CARD);
            ctx.drawText(tr, Text.literal("Accent preview  •  saved automatically"), contentX + 9, barY + 32, VectorClient.accentColor, false);
        }
        int y = searchY + 30;
        int cardH = gridView ? 56 : 39;
        int gap = 6;
        int visible = 0;
        for (Module m : modules) {
            if (!m.category.equals(selectedCategory)) continue;
            if (!search.isEmpty() && !(m.name + " " + m.description).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            int x = contentX;
            int w = contentW;
            if (y + cardH > panelY + panelH - 10) break;
            boolean hover = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + cardH;
            rounded(ctx, x, y, w, cardH, 7, hover ? CARD_HOVER : CARD);
            rounded(ctx, x + 6, y, w - 12, 1, 1, LINE);
            ctx.drawText(tr, Text.literal(m.name), x + 10, y + 7, TEXT, false);
            ctx.drawText(tr, Text.literal(m.description), x + 10, y + 20, MUTED, false);
            int sx = x + w - 28, sy = y + (cardH - 12) / 2;
            ctx.fill(sx, sy, sx + 20, sy + 12, m.enabled ? VectorClient.accentColor : 0xFF292C40);
            rounded(ctx, m.enabled ? sx + 10 : sx + 2, sy + 2, 8, 8, 4,
                    m.enabled ? 0xFFEDE9FF : 0xFF8588A0);
            visible++;
            y += cardH + gap;
        }
        if (visible == 0) ctx.drawText(tr, Text.literal("No modules found"), contentX + 8, y + 8, MUTED, false);
        ctx.drawText(tr, Text.literal("Right Shift  •  close menu"), panelX + sideW + 14,
                panelY + panelH - 13, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private static void rounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w / 2, h / 2)));
        if (r == 0) { ctx.fill(x, y, x + w, y + h, color); return; }
        for (int row = 0; row < h; row++) {
            int inset = 0;
            if (row < r) { double dy = r - row - 0.5; inset = Math.max(0, r - (int)Math.sqrt(Math.max(0, r * r - dy * dy))); }
            else if (row >= h - r) { double dy = row - (h - r) + 0.5; inset = Math.max(0, r - (int)Math.sqrt(Math.max(0, r * r - dy * dy))); }
            ctx.fill(x + inset, y + row, x + w - inset, y + row + 1, color);
        }
    }

    private void layout() {
        panelW = Math.min(620, Math.max(300, width - 20));
        panelH = Math.min(390, Math.max(190, height - 20));
        sideW = Math.min(142, Math.max(100, panelW / 3));
        panelX = Math.max(0, Math.min(width - panelW, (width - panelW) / 2 + offsetX));
        panelY = Math.max(0, Math.min(height - panelH, (height - panelH) / 2 + offsetY));
    }

    private String categoryIcon(String category) {
        return switch (category) {
            case "Combat" -> "⚔"; case "Misc" -> "◆"; case "Movement" -> "↗";
            case "Visual" -> "◉"; case "Settings" -> "☰"; case "Theme" -> "◐";
            case "Configs" -> "▱"; case "Keybinds" -> "⌨"; default -> "•";
        };
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button != 0) return super.mouseClicked(x, y, button);
        layout();
        int contentX = panelX + sideW + 14;
        int contentW = panelW - sideW - 28;
        int itemY = panelY + 62;
        for (String category : categories) {
            if (category.equals("Settings")) itemY += 15;
            if (x >= panelX + 7 && x <= panelX + sideW - 7 && y >= itemY - 4 && y <= itemY + 16) {
                selectedCategory = category; searching = false; search = ""; return true;
            }
            itemY += 23;
        }
        int searchY = panelY + 46;
        if (selectedCategory.equals("Theme")) {
            if (y >= searchY && y <= searchY + 110 && x >= contentX && x <= contentX + contentW) {
                float hue = ((float)(x - contentX) / Math.max(1, contentW));
                int rgb = java.awt.Color.HSBtoRGB(hue, 0.62f, 1.0f);
                VectorClient.accentColor = 0xFF000000 | (rgb & 0x00FFFFFF); VectorClient.saveConfig(); return true;
            }
        }
        if (x >= contentX && x <= contentX + contentW && y >= searchY && y <= searchY + 22) {
            if (x > contentX + contentW - 24) gridView = !gridView;
            else searching = true;
            return true;
        }
        int cardY = searchY + 30;
        int cardH = gridView ? 56 : 39;
        for (Module m : modules) {
            if (!m.category.equals(selectedCategory)) continue;
            if (!search.isEmpty() && !(m.name + " " + m.description).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            if (x >= contentX && x <= contentX + contentW && y >= cardY && y <= cardY + cardH) {
                m.enabled = !m.enabled;
                if (m.name.equals("Custom HUD")) VectorClient.hudEnabled = m.enabled;
                if (m.name.equals("Visual Effects")) VectorClient.visualEffectsEnabled = m.enabled;
                VectorClient.saveConfig();
                return true;
            }
            cardY += cardH + 6;
        }
        if (x >= panelX && x <= panelX + sideW && y >= panelY && y <= panelY + 42) {
            dragging = true; grabX = x - panelX; grabY = y - panelY;
        }
        return true;
    }

    @Override public boolean charTyped(char chr, int modifiers) {
        if (searching && !Character.isISOControl(chr)) { search += chr; return true; }
        return super.charTyped(chr, modifiers);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 344) { close(); return true; }
        if (searching) {
            if (keyCode == 256) { searching = false; return true; }
            if (keyCode == 259 && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean mouseDragged(double x, double y, int button, double deltaX, double deltaY) {
        if (!dragging) return super.mouseDragged(x, y, button, deltaX, deltaY);
        int baseX = (width - panelW) / 2;
        int baseY = (height - panelH) / 2;
        offsetX = (int) (x - grabX) - baseX;
        offsetY = (int) (y - grabY) - baseY;
        layout();
        return true;
    }
    @Override public boolean mouseReleased(double x, double y, int button) { dragging = false; return super.mouseReleased(x, y, button); }
    @Override public void close() { VectorClient.saveConfig(); MinecraftClient.getInstance().setScreen(null); }
}
