package com.vector.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class VectorClient implements ClientModInitializer {
    public static boolean hudEnabled = true;
    public static boolean visualEffectsEnabled = true;
    private static KeyBinding openMenu;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.vector.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.vector.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new VectorScreen());
                } else if (client.currentScreen instanceof VectorScreen) {
                    client.setScreen(null);
                }
            }
        });

        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!hudEnabled || client.textRenderer == null) return;

            int x = 8;
            int y = 8;
            context.fill(x - 4, y - 4, x + 142, y + 38, 0x660B0D10);
            context.fill(x - 4, y - 4, x - 2, y + 38, 0xFFB7D9D0);
            context.drawText(client.textRenderer, Text.literal("VECTOR"), x + 3, y, 0xFFE8F3F0, true);
            context.drawText(client.textRenderer, Text.literal("Minecraft 1.21.1"), x + 3, y + 12, 0xFFB9C7C3, false);
            context.drawText(client.textRenderer,
                    Text.literal("Effects: " + (visualEffectsEnabled ? "ON" : "OFF")),
                    x + 3, y + 24, 0xFFE8F3F0, false);
        });
    }
}
