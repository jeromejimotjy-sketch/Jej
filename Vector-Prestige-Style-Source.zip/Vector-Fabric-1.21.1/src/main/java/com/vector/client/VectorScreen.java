package com.vector.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Prestige-inspired, lightweight Vector module screen. No background blur is requested. */
public final class VectorScreen extends Screen {
    private static final int BG = 0xF20A0B18;
    private static final int SIDEBAR = 0xF6101222;
    private static final int CARD = 0xF8141729;
    private static final int CARD_HOVER = 0xFF1D2038;
    private static final int LINE = 0xFF292D48;
    private static final int PURPLE = 0xFF8B70FF;
    private static final int TEXT = 0xFFF1F0FF;
    private static final int MUTED = 0xFF8E91AE;

    private final String[] categories = {"Combat", "Misc", "Movement", "Visual", "Settings", "Theme", "Configs", "Keybinds"};
    private String selectedCategory = "Visual";
    private String search = "";
    private boolean searching = false;
    private boolean gridView = false;
    private int panelX, panelY, panelW, panelH, sideW;
    private boolean dragging;
    private double grabX, grabY;
    private int offsetX, offsetY;

    private static final class Module {
        final String category, name, description;
        boolean enabled;
        Module(String category, String name, String description, boolean enabled) {
            this.category = category; this.name = name; this.description = description; this.enabled = enabled;
        }
    }

    private final List<Module> modules = new ArrayList<>(List.of(
        new Module("Visual", "Custom HUD", "Displays the Vector status HUD", true),
        new Module("Visual", "Visual Effects", "Toggle Vector's visual effects", true),
        new Module("Visual", "Name Tags", "Module placeholder — no player tracking", false),
        new Module("Visual", "Jump Circles", "Decorative landing ring effects", false),
        new Module("Visual", "Pearl Trajectory", "Shows a projected pearl path", false),
        new Module("Combat", "Combat HUD", "Displays combat-related status", false),
        new Module("Movement", "Movement HUD", "Displays movement status", false),
        new Module("Misc", "Notifications", "Show client notifications", true)
    ));

    public VectorScreen() { super(Text.literal("Vector Client")); }

    @Override public boolean shouldPause() { return false; }

    // Intentionally suppress vanilla's screen background/blur. We draw our own dim overlay.
    @Override public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) { }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x72040712);
        layout();
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, BG);
        ctx.fill(panelX, panelY, panelX + sideW, panelY + panelH, SIDEBAR);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 1, PURPLE);
        ctx.fill(panelX + sideW, panelY + 12, panelX + sideW + 1, panelY + panelH - 12, LINE);

        var tr = MinecraftClient.getInstance().textRenderer;
        ctx.drawText(tr, Text.literal("◆  VECTOR"), panelX + 13, panelY + 13, PURPLE, false);
        ctx.drawText(tr, Text.literal("CLIENT  •  1.21.1"), panelX + 14, panelY + 27, MUTED, false);
        ctx.drawText(tr, Text.literal("MODULES"), panelX + 14, panelY + 49, MUTED, false);

        int itemY = panelY + 62;
        for (String category : categories) {
            if (category.equals("Settings")) {
                ctx.drawText(tr, Text.literal("GENERAL"), panelX + 14, itemY + 2, MUTED, false);
                itemY += 15;
            }
            boolean active = selectedCategory.equals(category);
            int x1 = panelX + 7, x2 = panelX + sideW - 7;
            if (active) {
                ctx.fill(x1, itemY - 4, x2, itemY + 16, 0xFF28234A);
                ctx.fill(x1, itemY - 4, x1 + 2, itemY + 16, PURPLE);
            }
            ctx.drawText(tr, Text.literal(categoryIcon(category) + "  " + category), panelX + 15, itemY + 2,
                    active ? TEXT : 0xFFB7B8CD, false);
            itemY += 23;
        }

        int contentX = panelX + sideW + 14;
        int contentW = panelW - sideW - 28;
        String title = selectedCategory.equals("Visual") ? "Visual Modules" : selectedCategory;
        ctx.drawText(tr, Text.literal(title), contentX, panelY + 14, TEXT, false);
        int count = 0;
        for (Module m : modules) if (m.category.equals(selectedCategory)) count++;
        ctx.drawText(tr, Text.literal(selectedCategory.equals("Visual") ? "Modules and visual options" : "Vector settings and modules"),
                contentX, panelY + 28, MUTED, false);

        int searchY = panelY + 46;
        ctx.fill(contentX, searchY, contentX + contentW, searchY + 22, 0xFF101326);
        ctx.fill(contentX, searchY, contentX + contentW, searchY + 1, LINE);
        String searchLabel = searching ? "Search: " + search + "_" : (search.isEmpty() ? "⌕  Search modules" : "⌕  " + search);
        ctx.drawText(tr, Text.literal(searchLabel), contentX + 8, searchY + 7, searching ? TEXT : MUTED, false);
        ctx.drawText(tr, Text.literal(gridView ? "▦" : "☷"), contentX + contentW - 15, searchY + 7, TEXT, false);

        int y = searchY + 30;
        int cardH = gridView ? 56 : 39;
        int gap = 6;
        int visible = 0;
        for (Module m : modules) {
            if (!m.category.equals(selectedCategory)) continue;
            if (!search.isEmpty() && !(m.name + " " + m.description).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            int x = contentX;
            int w = contentW;
            if (y + cardH > panelY + panelH - 10) break;
            boolean hover = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + cardH;
            ctx.fill(x, y, x + w, y + cardH, hover ? CARD_HOVER : CARD);
            ctx.fill(x, y, x + w, y + 1, LINE);
            ctx.drawText(tr, Text.literal(m.name), x + 10, y + 7, TEXT, false);
            ctx.drawText(tr, Text.literal(m.description), x + 10, y + 20, MUTED, false);
            int sx = x + w - 28, sy = y + (cardH - 12) / 2;
            ctx.fill(sx, sy, sx + 20, sy + 12, m.enabled ? 0xFF5140A3 : 0xFF292C40);
            ctx.fill(m.enabled ? sx + 10 : sx + 2, sy + 2, m.enabled ? sx + 18 : sx + 10, sy + 10,
                    m.enabled ? 0xFFEDE9FF : 0xFF8588A0);
            visible++;
            y += cardH + gap;
        }
        if (visible == 0) ctx.drawText(tr, Text.literal("No modules found"), contentX + 8, y + 8, MUTED, false);
        ctx.drawText(tr, Text.literal("Right Shift  •  close menu"), panelX + sideW + 14,
                panelY + panelH - 13, MUTED, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void layout() {
        panelW = Math.min(620, Math.max(300, width - 20));
        panelH = Math.min(390, Math.max(190, height - 20));
        sideW = Math.min(142, Math.max(100, panelW / 3));
        panelX = Math.max(0, Math.min(width - panelW, (width - panelW) / 2 + offsetX));
        panelY = Math.max(0, Math.min(height - panelH, (height - panelH) / 2 + offsetY));
    }

    private String categoryIcon(String category) {
        return switch (category) {
            case "Combat" -> "⚔"; case "Misc" -> "◆"; case "Movement" -> "↗";
            case "Visual" -> "◉"; case "Settings" -> "☰"; case "Theme" -> "◐";
            case "Configs" -> "▱"; case "Keybinds" -> "⌨"; default -> "•";
        };
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button != 0) return super.mouseClicked(x, y, button);
        layout();
        int contentX = panelX + sideW + 14;
        int contentW = panelW - sideW - 28;
        int itemY = panelY + 62;
        for (String category : categories) {
            if (category.equals("Settings")) itemY += 15;
            if (x >= panelX + 7 && x <= panelX + sideW - 7 && y >= itemY - 4 && y <= itemY + 16) {
                selectedCategory = category; searching = false; search = ""; return true;
            }
            itemY += 23;
        }
        int searchY = panelY + 46;
        if (x >= contentX && x <= contentX + contentW && y >= searchY && y <= searchY + 22) {
            if (x > contentX + contentW - 24) gridView = !gridView;
            else searching = true;
            return true;
        }
        int cardY = searchY + 30;
        int cardH = gridView ? 56 : 39;
        for (Module m : modules) {
            if (!m.category.equals(selectedCategory)) continue;
            if (!search.isEmpty() && !(m.name + " " + m.description).toLowerCase(Locale.ROOT).contains(search.toLowerCase(Locale.ROOT))) continue;
            if (x >= contentX && x <= contentX + contentW && y >= cardY && y <= cardY + cardH) {
                m.enabled = !m.enabled;
                if (m.name.equals("Custom HUD")) VectorClient.hudEnabled = m.enabled;
                if (m.name.equals("Visual Effects")) VectorClient.visualEffectsEnabled = m.enabled;
                return true;
            }
            cardY += cardH + 6;
        }
        if (x >= panelX && x <= panelX + sideW && y >= panelY && y <= panelY + 42) {
            dragging = true; grabX = x - panelX; grabY = y - panelY;
        }
        return true;
    }

    @Override public boolean charTyped(char chr, int modifiers) {
        if (searching && !Character.isISOControl(chr)) { search += chr; return true; }
        return super.charTyped(chr, modifiers);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (searching) {
            if (keyCode == 256) { searching = false; return true; }
            if (keyCode == 259 && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean mouseDragged(double x, double y, int button, double deltaX, double deltaY) {
        if (!dragging) return super.mouseDragged(x, y, button, deltaX, deltaY);
        int baseX = (width - panelW) / 2;
        int baseY = (height - panelH) / 2;
        offsetX = (int) (x - grabX) - baseX;
        offsetY = (int) (y - grabY) - baseY;
        layout();
        return true;
    }
    @Override public boolean mouseReleased(double x, double y, int button) { dragging = false; return super.mouseReleased(x, y, button); }
    @Override public void close() { MinecraftClient.getInstance().setScreen(null); }
}
