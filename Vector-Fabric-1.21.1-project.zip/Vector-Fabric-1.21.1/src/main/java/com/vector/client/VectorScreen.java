package com.vector.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class VectorScreen extends Screen {
    private int panelX = 36, panelY = 48, panelW = 240, panelH = 170;
    private boolean dragging, resizing;
    private double grabX, grabY;

    private static final int PANEL = 0xE6101316;
    private static final int HEADER = 0xF01C2326;
    private static final int ACCENT = 0xFFB7D9D0;

    public VectorScreen() {
        super(Text.literal("Vector"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x30000000);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, PANEL);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 25, HEADER);
        ctx.fill(panelX, panelY, panelX + 2, panelY + panelH, ACCENT);

        var tr = MinecraftClient.getInstance().textRenderer;
        ctx.drawText(tr, Text.literal("VECTOR"), panelX + 10, panelY + 8, 0xFFE8F3F0, true);
        ctx.drawText(tr, Text.literal("×"), panelX + panelW - 15, panelY + 7, 0xFFE8F3F0, true);

        ctx.drawText(tr, Text.literal("CLIENT HUD"), panelX + 12, panelY + 38, 0xFFB9C7C3, false);
        drawRow(ctx, panelY + 53, "HUD: " + (VectorClient.hudEnabled ? "ON" : "OFF"));
        drawRow(ctx, panelY + 85, "Visual effects: " + (VectorClient.visualEffectsEnabled ? "ON" : "OFF"));
        ctx.drawText(tr, Text.literal("Drag header • bottom-right resizes"),
                panelX + 10, panelY + panelH - 18, 0xFF91A29D, false);
        ctx.fill(panelX + panelW - 8, panelY + panelH - 8, panelX + panelW, panelY + panelH, ACCENT);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawRow(DrawContext ctx, int y, String label) {
        ctx.fill(panelX + 10, y, panelX + panelW - 10, y + 25, 0x88313B3D);
        ctx.drawText(MinecraftClient.getInstance().textRenderer, Text.literal(label),
                panelX + 18, y + 8, 0xFFE8F3F0, false);
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button != 0) return super.mouseClicked(x, y, button);

        if (x >= panelX + panelW - 22 && x <= panelX + panelW
                && y >= panelY && y <= panelY + 25) {
            close();
            return true;
        }
        if (insideRow(x, y, panelY + 53)) {
            VectorClient.hudEnabled = !VectorClient.hudEnabled;
            return true;
        }
        if (insideRow(x, y, panelY + 85)) {
            VectorClient.visualEffectsEnabled = !VectorClient.visualEffectsEnabled;
            return true;
        }
        if (x >= panelX + panelW - 14 && y >= panelY + panelH - 14) {
            resizing = true;
            return true;
        }
        if (x >= panelX && x <= panelX + panelW && y >= panelY && y <= panelY + 25) {
            dragging = true;
            grabX = x - panelX;
            grabY = y - panelY;
            return true;
        }
        return true;
    }

    private boolean insideRow(double x, double y, int rowY) {
        return x >= panelX + 10 && x <= panelX + panelW - 10 && y >= rowY && y <= rowY + 25;
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double deltaX, double deltaY) {
        if (dragging) {
            panelX = (int) (x - grabX);
            panelY = (int) (y - grabY);
            clamp();
            return true;
        }
        if (resizing) {
            panelW = Math.max(190, Math.min(420, (int) x - panelX));
            panelH = Math.max(145, Math.min(320, (int) y - panelY));
            return true;
        }
        return super.mouseDragged(x, y, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        dragging = false;
        resizing = false;
        return super.mouseReleased(x, y, button);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(null);
    }

    private void clamp() {
        panelX = Math.max(0, Math.min(width - panelW, panelX));
        panelY = Math.max(0, Math.min(height - 25, panelY));
    }
}
