# Vector — Fabric 1.21.1

This is a real Fabric Loom project (not a JAR compiled against fake API stubs).

Features:
- Right Shift opens/closes the Vector panel.
- Drag the header to move the panel.
- Drag the bottom-right corner to resize it.
- HUD toggle and a visual-effects status toggle.
- Minimal translucent HUD.

The visual-effects toggle currently changes the displayed status only; actual particle/shader effects are not implemented yet.

## Build
Use Java 21 and Gradle 8.10.2, then run:
    gradle build

The remapped mod JAR should be in `build/libs/`.

You can also push this project to a GitHub repository and run the included Actions workflow; download the `Vector-Minecraft-1.21.1` artifact from the completed workflow.

Target dependencies:
- Minecraft 1.21.1
- Yarn 1.21.1+build.3
- Fabric Loader 0.19.5
- Fabric API 0.116.17+1.21.1
